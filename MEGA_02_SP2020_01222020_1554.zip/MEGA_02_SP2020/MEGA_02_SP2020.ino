// below are the inout/output pins for the system

const int RELAY1 = 2;
const int RELAY2 = 3;
const int RELAY3 = 4;
const int RELAY4 = 5;
const int RELAY5 = 6;
const int RELAY6 = 7;

const int UART_RXD = 14;
const int UART_TXD = 15;

const int SD_CS = 53;

const int LED_PIN = 13;

const int SPEAKER_PIN = 9;

const int RTC_INT = 19;
const int RTC_SDA = 20;
const int RTC_SCL = 21;

const int LCD_PWR   = 27;
const int LCD_DC    = 49;
const int LCD_CS    = 47;
const int LCD_MOSI  = 51;
const int LCD_CLK   = 52;
const int LCD_RST   = 48;
const int LCD_MISO  = 50;
const int LCD_BACKLIGHT = 46;

const int TOUCH_IRQ = 18;
const int TOUCH_DO  = 50;
const int TOUCH_DIN = 51;
const int TOUCH_CS  = 28;
const int TOUCH_CLK = 52;

const int ESP_PWR   = 26;
const int ESP_CHPD  = 25;
const int ESP_GPIO0 = 24;
const int ESP_GPIO2 = 23;
const int ESP_RST   = 22;

const int DOUT38  = 38;
const int DOUT39  = 39;
const int DOUT40  = 40;
const int DOUT41  = 41;
const int DOUT42  = 42;
const int DOUT43  = 43;
const int DOUT44  = 44;
const int DOUT45  = 45;

const int DIN30 = 30;
const int DIN31 = 31;
const int DIN32 = 32;
const int DIN33 = 33;
const int DIN34 = 34;
const int DIN35 = 35;
const int DIN36 = 36;
const int DIN37 = 37;




int state=0;





void setup() {
  // put your setup code here, to run once:
pinMode(DIN30,INPUT_PULLUP);
pinMode(DIN31,INPUT_PULLUP);
pinMode(DIN32,INPUT_PULLUP);
pinMode(DIN33,INPUT_PULLUP);
pinMode(DIN34,INPUT_PULLUP);
pinMode(DIN35,INPUT_PULLUP);
pinMode(DIN36,INPUT_PULLUP);
pinMode(DIN37,INPUT_PULLUP);

pinMode(DOUT38,OUTPUT);
pinMode(DOUT39,OUTPUT);
pinMode(DOUT40,OUTPUT);
pinMode(DOUT41,OUTPUT);
pinMode(DOUT42,OUTPUT);
pinMode(DOUT43,OUTPUT);
pinMode(DOUT44,OUTPUT);
pinMode(DOUT45,OUTPUT);

pinMode(RELAY1,OUTPUT);
pinMode(RELAY2,OUTPUT);
pinMode(RELAY3,OUTPUT);
pinMode(RELAY4,OUTPUT);
pinMode(RELAY5,OUTPUT);
pinMode(RELAY6,OUTPUT);

pinMode(SPEAKER_PIN,OUTPUT);


//this turns on the LED so you know it is running
pinMode(13,OUTPUT);
analogWrite(LED_PIN,255);
//this opens a serial connection through the USB cable to a popup window on the screen so you can watch what is going on.
Serial.begin(115200);
}




void loop() {
  // put your main code here, to run repeatedly:

switch (state) {
  case 0:
    //do something when stater equals 0
  digitalWrite(DOUT38,HIGH);digitalWrite(DOUT39,LOW);
    break;

    
  case 1:
    //do something when state equals 1
 digitalWrite(DOUT38,LOW);digitalWrite(DOUT39,HIGH);
    break;

    
  case 2:
    //do something when state equals 2

    break;

    
  default:
    // if nothing else matches, do the default
    // default is optional

    
    break;
}

state=!digitalRead(DIN30);

if(!digitalRead(DIN30)==LOW){
  Serial.println("Off");
}

if(!digitalRead(DIN30)==HIGH){
  Serial.println("On");
}

// don't delete the bracket below
}
